package com.erha.autosdb.data.network.model

data class AutoDto (
    var id: Long
)
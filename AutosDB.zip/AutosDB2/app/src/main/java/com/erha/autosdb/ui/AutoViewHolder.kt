package com.erha.autosdb.ui

import androidx.recyclerview.widget.RecyclerView
import com.erha.autosdb.data.db.model.AutoEntity
import com.erha.autosdb.databinding.GameElementBinding

class AutoViewHolder (
    private val binding: GameElementBinding
): RecyclerView.ViewHolder(binding.root) {

    fun bind(game: AutoEntity){
        binding.apply {
            tvTitle.text = game.marca
            tvGenre.text = game.modelo
            tvDeveloper.text = game.colors
        }
    }
}

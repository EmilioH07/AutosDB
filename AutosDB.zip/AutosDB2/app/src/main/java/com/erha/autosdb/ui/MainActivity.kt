package com.erha.autosdb.ui

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.erha.autosdb.databinding.ActivityMainBinding
import com.erha.autosdb.R
import com.erha.autosdb.application.AutosDBApp
import com.erha.autosdb.data.AutoRepository
import com.erha.autosdb.data.db.AutoDao
import com.erha.autosdb.data.db.model.AutoEntity
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var games: MutableList<AutoEntity> = mutableListOf()
    private lateinit var repository: AutoRepository

    private lateinit var gameAdapter: AutoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        repository = (application as AutosDBApp).repository

        gameAdapter = AutoAdapter{ selectedGame ->

            //Click al registro de cada juego

            val dialog = AutoDialog(newGame = false, game = selectedGame, updateUI = {
                updateUI()
            }, message = { text ->
                //Aquí va la función para los mensajes
                message(text)
            })

            dialog.show(supportFragmentManager, "dialog2")

            /*Toast.makeText(
                this,
                "Click en el juego: ${game.title}, con género ${game.genre}",
                Toast.LENGTH_SHORT
            )
                .show()*/
        }

        //Establezco el recyclerview
        binding.rvGames.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = gameAdapter
        }




        /*val game = GameEntity(
            title = "FIFA 23",
            genre = "Deportes",
            developer = "EA Sports",
        )

        lifecycleScope.launch {
            repository.insertGame(game)
        }*/

        updateUI()

    }

    fun click(view: View) {
        //Manejamos el click del floating action button

        val dialog = AutoDialog(updateUI = {
            updateUI()
        }, message = { text ->
            //Aquí va el mensaje
            message(text)

        })


        dialog.show(supportFragmentManager, "dialog1")

    }

    private fun message(text: String){
        /*Toast.makeText(
            this,
            text,
            Toast.LENGTH_SHORT
        ).show()*/

        Snackbar.make(
            binding.cl,
            text,
            Snackbar.LENGTH_SHORT
        )
            .setTextColor(getColor(R.color.white))
            .setBackgroundTint(getColor(R.color.snackbar))
            .show()

        //#9E1734
    }

    private fun updateUI(){
        lifecycleScope.launch {
            games = repository.getAllAutos()

            binding.tvSinRegistros.visibility =
                if(games.isNotEmpty()) View.INVISIBLE else View.VISIBLE

            gameAdapter.updateList(games)
        }
    }
}